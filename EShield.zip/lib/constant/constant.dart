// ignore: non_constant_identifier_names
String LOGIN_SCREEN = '/Login',
    // ignore: non_constant_identifier_names
    SIGN_UP_SCREEN = '/SignUp',
    // ignore: non_constant_identifier_names
    ANIMATED_SPLASH = '/SplashScreen',
    // ignore: non_constant_identifier_names
    HOME_SCREEN = '/WelcomeScreenWidget',
    // ignore: non_constant_identifier_names
    WELCOME_PAGE = '/WelcomePage',
    // ignore: non_constant_identifier_names
    App_Screen = '/App';
