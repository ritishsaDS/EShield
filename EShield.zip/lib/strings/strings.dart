class Strings {
  static const String responseCode = 'response_code';
  static const String responseSuccess = '1';
}
